package com.charan;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.mashape.unirest.http.exceptions.UnirestException;

import jakarta.mail.MessagingException;

 

@RestController

public class EmailController {
	
	@GetMapping ("/")
	public String sayHello() {
		return "<h1> Hello, From Charan Kumar </h1>";
	}

	@GetMapping("/Hello")
	public String sayHelloForUser(@RequestParam String userName) {
		return "<h1> Hello " + userName + ",Welcome to my System...</h1>";
	}
    @Autowired
    private EmailService emailService;
    
  //  @Autowired
 //   private MailgunService mailGunEmailService;
/*
    @PostMapping("/email/send")
    public String sendEmail() {
        try {
            emailService.sendEmail("kcharankumar@gmail.com", "hello", "hello");
            return "Email sent successfully!";
        } catch (MessagingException e) {
            return "Error sending email: " + e.getMessage();
        }
    }
   */ 
    
    @PostMapping("/email/send")
    public String sendEmailViaGetMapping(@RequestParam String toEmail, @RequestParam String heading, @RequestParam String body) {
        try {
            emailService.sendEmail(toEmail, heading, body);
            return "Email sent successfully!";
        } catch (MessagingException e) {
            return "Error sending email: " + e.getMessage();
        }
    }
    
	
    
}

